import { PrismaService } from "../../../database/prisma.service";
import { ActivityDomain } from "../domain/activity.domain";
import { ActivityWithLocation } from "../activity.service";

export function toActivityDomain(activity: ActivityWithLocation): ActivityDomain {
  return new ActivityDomain(
    activity.id,
    activity.title,
    activity.status,
    activity.startDate,
  );
}

export function DatePassed(startDate: string | null, now: Date = new Date()): boolean {
  if (!startDate) {
    return false;
  }
  const parsed = new Date(startDate);
  if (Number.isNaN(parsed.getTime())) {
    return false;
  }
  return parsed.getTime() < now.getTime();
}

export async function applyExpiration(
  activity: ActivityWithLocation,
  prisma: PrismaService,
  now: Date = new Date(),
): Promise<ActivityWithLocation> {
  if (!DatePassed(activity.startDate, now)) {
    return activity;
  }

  const domain = toActivityDomain(activity);

  try {
    domain.finish();
  } catch {
    return activity;
  }

  if (domain.status !== activity.status) {
    await prisma.activity.update({
      where: { id: activity.id },
      data: { status: domain.status },
    });
  }

  return {
    ...activity,
    status: domain.status,
  };
}