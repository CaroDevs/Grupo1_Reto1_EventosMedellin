import { PrismaService } from "../../database/prisma.service";
import { CreateActivityDto } from "./dto/create-activity.dto";
import { IActivityBuilder } from "./Interfaces/activity.interface";
import { ActivityBuilder } from "./builder/activity.builder";
import { UpdateActivityDto } from "./dto/update-activity.dto";
import { FilterActivitiesDto } from "./dto/filter-activities.dto";
import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { ActivityLocationPort, ActivityWithLocation } from "./adapter/activity.location.port";
import { applyExpiration, toActivityDomain } from "./helpers/activityhelpers";

export type { ActivityWithLocation } from "./adapter/activity.location.port";

@Injectable()
export class ActivityService
{
    constructor(
        private readonly prisma: PrismaService,
        private readonly locationPort: ActivityLocationPort,
    ){}

    async create(dto: CreateActivityDto): Promise<ActivityWithLocation> {
    const builder: IActivityBuilder = ActivityBuilder.fromDto(dto);
    const activityData = builder.build();

    const created = await this.prisma.activity.create({
      data: activityData,
    });

    await this.setLocation(created.id, dto.latitude, dto.longitude);

    return this.findOne(created.id);
  }

  async findAll(
    filters: FilterActivitiesDto = {},
    includeDrafts = false,
  ): Promise<ActivityWithLocation[]> {
    const rows = await this.locationPort.findAll(filters);
    const items: ActivityWithLocation[] = [];

    for (const row of rows) {
      const evaluated = await applyExpiration(row, this.prisma);
      if (includeDrafts || evaluated.status !== 'DRAFT') {
        items.push(evaluated);
      }
    }

    return items;
  }

  async findOne(id: string): Promise<ActivityWithLocation> {
    const activity = await this.locationPort.findById(id);
    if (!activity) {
      throw new NotFoundException(`Actividad con id ${id} no encontrada`);
    }

    return applyExpiration(activity, this.prisma);
  }

    async update(id: string, dto: UpdateActivityDto): Promise<ActivityWithLocation> {
        const current = await this.findOne(id);
        const domain = toActivityDomain(current);

        if (!domain.canEdit()) {
        throw new BadRequestException(
            `No se puede editar una actividad en estado ${domain.status}`,
        );
        }

        const { latitude, longitude, ...rest } = dto;
        await this.prisma.activity.update({
        where: { id },
        data: rest,
        });

        await this.setLocation(id, latitude, longitude);

        return this.findOne(id);
  }

  async publish(id: string): Promise<ActivityWithLocation> {
    const current = await this.findOne(id);
    const domain = toActivityDomain(current);

    domain.publish();

    await this.prisma.activity.update({
      where: { id },
      data: { status: domain.status },
    });

    return this.findOne(id);
  }

  async cancel(id: string): Promise<ActivityWithLocation> {
    const current = await this.findOne(id);
    const domain = toActivityDomain(current);

    domain.cancel();

    await this.prisma.activity.update({
      where: { id },
      data: { status: domain.status },
    });

    return this.findOne(id);
  }

  async remove(id: string): Promise<ActivityWithLocation> {
    const current = await this.findOne(id);
    await this.prisma.activity.delete({ where: { id } });
    return current;
  }

  private async setLocation(
    id: string,
    latitude?: number,
    longitude?: number,
  ): Promise<void> {
    if (latitude === undefined || longitude === undefined) {
      return;
    }
    await this.locationPort.setCoordinates(id, latitude, longitude);
  }
}
